var circlex =circlex = 80;
var circlex= circlex+100;
function setup() {
  createCanvas(400, 400);
  //background
  background(200);
  
}

function draw() {
    //background
  background(200);
  ellipse(200,100,100,100);
  
    //ellipse
  fill(0,100,200)
  ellipse(mouseX,mouseY,125,250,50,50);

  //rectangle 
  fill(200,250,100)
  rect(290,200,78,90);
  
  //square
  fill(200,250,100)
  square(mouseY,150,75,60,15);
  
  
  
}